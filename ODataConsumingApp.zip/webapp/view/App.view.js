sap.ui.jsview("northwind.ODataConsumingApp.view.App", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf northwind.ODataConsumingApp.view.App
	 */
	getControllerName: function() {
		return "northwind.ODataConsumingApp.controller.App";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away. 
	 * @memberOf northwind.ODataConsumingApp.view.App
	 */
	createContent: function(oController) {
		
		// to avoid scroll bars on desktop the root view must be set to block display
		this.setDisplayBlock(true);
		
		// create app
		this.app = new sap.m.SplitApp();
		
		// load the master page
		var master = sap.ui.xmlview("Master", "northwind.ODataConsumingApp.view.Master");
		master.getController().nav = this.getController();
		this.app.addPage(master, true);
		
		// load the empty page
		var empty = sap.ui.xmlview("Empty", "northwind.ODataConsumingApp.view.Empty");
		empty.getController().nav = this.getController();
		this.app.addPage(empty, false);
		
		// load the detail page
		var detail = sap.ui.xmlview("Detail", "northwind.ODataConsumingApp.view.Detail");
		detail.getController().nav = this.getController();
		this.app.addPage(detail, false);
		
		var invoice = sap.ui.xmlview("Invoice", "northwind.ODataConsumingApp.view.Invoice");
		invoice.getController().nav = this.getController();
		this.app.addPage(invoice, false);
		
		// var oPage = new sap.m.Page({
		// 	title: "Title",
		// 	content: []
		// });

		// var app = new sap.m.App("myApp", {
		// 	initialPage: "oPage"
		// });
		// app.addPage(oPage);
		return this.app;
	}

});