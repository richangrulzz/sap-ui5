sap.ui.define([
	"sap/ui/core/format/DateFormat"
],	function () {
	"use strict";
	
	return {
		
	date : function (value){
		if(value){
			var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({pattern: "dd-MM-yyyy"});
			return oDateFormat.format(new Date(value));
		}else{
			return value;
		}
	 }
   };
});