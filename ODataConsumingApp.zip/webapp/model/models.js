sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function(JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function() {
			 var oModel = new sap.ui.model.json.JSONModel({
				isPhone   : sap.ui.Device.browser.mobile,
				isNoPhone : !sap.ui.Device.browser.mobile,
				listMode  : (sap.ui.Device.browser.mobile) ? "None" : "SingleSelectMaster",
				listItemType : (sap.ui.Device.browser.mobile) ? "Active" : "Inactive"
			});
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		}

	};
});